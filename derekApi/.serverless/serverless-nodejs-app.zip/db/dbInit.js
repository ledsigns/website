global.Vendor = require("./models/vendor");
global.Category = require("./models/category");
global.Product = require("./models/product");
global.ProductDetail = require("./models/productDetail");
global.Image = require("./models/image");
global.Test = require("./models/test");
